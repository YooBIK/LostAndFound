package hongik.ce.LostAndFound;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LostAndFoundApplicationTests {

	@Test
	void contextLoads() {
	}

}
